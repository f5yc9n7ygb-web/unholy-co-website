/**
 * Placeholder postinstall so platforms that run it do not fail.
 */
console.log("UNHOLY CO postinstall complete.")
